package com.samco.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.samco.model.Samco;
import com.samco.repository.SamcoRepository;

@RestController
@RequestMapping("/samco")
public class SamcoController {

	@Autowired
	SamcoRepository samcoRepository;

	@PostMapping("/post")
	public int saveSamco(@RequestBody Samco samco) {
		return samcoRepository.save(samco);
	}

	@GetMapping("/get")
	public List<Samco> getSamco() {
		return samcoRepository.findAll();
	}

	@GetMapping("/get/{id}")
	public Samco getById(@PathVariable("id") int id) {
		return samcoRepository.findById(id);
	}

	@DeleteMapping("/delete/{id}")
	public int deleteById(@PathVariable("id") int id) {
		return samcoRepository.deleteById(id);
	}

	@DeleteMapping("/delete")
	public int delete() {
		return samcoRepository.deleteAll();
	}

}
