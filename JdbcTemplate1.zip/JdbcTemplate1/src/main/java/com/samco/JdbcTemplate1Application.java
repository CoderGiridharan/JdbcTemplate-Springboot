package com.samco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcTemplate1Application {

	public static void main(String[] args) {
		SpringApplication.run(JdbcTemplate1Application.class, args);
	}

}
