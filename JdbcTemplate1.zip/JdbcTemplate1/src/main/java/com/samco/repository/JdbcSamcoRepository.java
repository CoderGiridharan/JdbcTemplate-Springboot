package com.samco.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.samco.model.Samco;

@Repository
public class JdbcSamcoRepository implements SamcoRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int save(Samco samco) {
		return jdbcTemplate.update("INSERT INTO Samco(id,name,email) VALUES(?,?,?)",
				new Object[] { samco.getId(), samco.getName(), samco.getEmail() });
	}

	public int update(Samco samco) {
		return jdbcTemplate.update("UPDATE samco SET id=?,name=?,email=? WHERE id=?",
				new Object[] { samco.getId(), samco.getName(), samco.getEmail() });
	}

	public Samco findById(int id) {
		try {

			Samco samco = jdbcTemplate.queryForObject("SELECT * FROM samco WHERE id=?",
					BeanPropertyRowMapper.newInstance(Samco.class), id);
			return samco;

		} catch (IncorrectResultSizeDataAccessException e) {
			return null;
		}
	}
	
	public int deleteById(int id) {
		return jdbcTemplate.update("DELETE FROM samco WHERE id = ?",id);
	}
	
	
	public List<Samco> findAll(){
		return jdbcTemplate.query("SELECT * from samco",BeanPropertyRowMapper.newInstance(Samco.class));
	}
	
	public int deleteAll() {
		return jdbcTemplate.update("DELETE from samco");
	}

}
