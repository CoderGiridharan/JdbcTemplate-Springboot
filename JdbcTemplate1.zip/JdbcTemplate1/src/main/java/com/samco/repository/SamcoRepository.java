package com.samco.repository;

import java.util.List;
import com.samco.model.Samco;



public interface SamcoRepository {
	
		int  save(Samco samco);	
		
		int update (Samco samco);
		
		Samco findById(int id);
		
		int deleteById(int id);
		
		List<Samco> findAll();
		
		int deleteAll();
}
